
## GG Cafe

GG Cafe is a signpainter-style flat brush script font, a mix between connecting and non-connecting letterforms. The design nods to classic 1930s typefaces like Gillies Gothic & Kaufmann.

### License

Based on [Yellowtail](https://github.com/google/fonts/tree/main/apache/yellowtail) by Brian J. Bonislawsky DBA Astigmatic (AOETI). Copyright 2011 Brian J. Bonislawsky DBA Astigmatic (AOETI). All Rights Reserved. Licensed under the [Apache License v2.0](https://www.apache.org/licenses/LICENSE-2.0.txt).

### Using this font

You may create your own fonts based on this font, and you may incorporate portions of this font into your own font. You may publish your own font under any license, including a commercial license, but you must:

- in _Font Info › Legal › Copyright_, include `Portions Copyright 2011 Brian J. Bonislawsky DBA Astigmatic (AOETI).`
- in _Font Info › Legal › License_, include `Portions licensed under the Apache License v2.0.`
