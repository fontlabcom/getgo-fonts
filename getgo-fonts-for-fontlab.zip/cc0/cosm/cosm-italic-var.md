## GG Cosm

GG Cosm is a neo-grotesque sanserif font family with a weight axis, in two inclinations: upright and italic.

It contains 359 glyphs and 5 OpenType features, and supports 358 characters from the Unicode blocks: Latin Extended-A, Basic Latin, Latin-1 Supplement, General Punctuation, Mathematical Operators, Spacing Modifier Letters, Latin Extended Additional, Latin Extended-B.

### License

Based on Aileron 0.102 by [Sora Sagano](http://dotcolon.net/font/aileron).

Dedicated to the public domain via the [CC0 1.0 Universal Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/). No rights reserved.

The person who associated a work with this deed has dedicated the work to the public domain by waiving all of his or her rights to the work worldwide under copyright law, including all related and neighboring rights, to the extent allowed by law. You can copy, modify, distribute and perform the work, even for commercial purposes, all without asking permission.

### Using this font

You may create your own fonts based on this font, and you may incorporate portions of this font into your own font. You may publish your own font under any license, including a commercial license, without any limitations.

