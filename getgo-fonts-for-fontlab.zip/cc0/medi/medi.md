## GG Medi

GG Medi is a Didone serif font.

It contains 103 glyphs, and supports 102 characters from the Unicode blocks: Basic Latin, General Punctuation.

### License

Based on Medio 0.200 by [Sora Sagano](http://dotcolon.net/font/medio).

Dedicated to the public domain via the [CC0 1.0 Universal Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/). No rights reserved.

The person who associated a work with this deed has dedicated the work to the public domain by waiving all of his or her rights to the work worldwide under copyright law, including all related and neighboring rights, to the extent allowed by law. You can copy, modify, distribute and perform the work, even for commercial purposes, all without asking permission.

### Using this font

You may create your own fonts based on this font, and you may incorporate portions of this font into your own font. You may publish your own font under any license, including a commercial license, without any limitations.

