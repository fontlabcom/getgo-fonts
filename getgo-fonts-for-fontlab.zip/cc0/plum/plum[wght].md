
## GG Plum

GG Plum is a humanist sanserif font family with a weight axis.

It contains 205 glyphs and 3 OpenType features, and supports 204 characters from the Unicode blocks: Basic Latin, Latin-1 Supplement, Latin Extended-A, General Punctuation, Latin Extended Additional, Spacing Modifier Letters.

### License

Based on Vegur 0.701 by [Sora Sagano](http://www.dotcolon.net/font/vegur).

Dedicated to the public domain via the [CC0 1.0 Universal Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/). No rights reserved.

The person who associated a work with this deed has dedicated the work to the public domain by waiving all of his or her rights to the work worldwide under copyright law, including all related and neighboring rights, to the extent allowed by law. You can copy, modify, distribute and perform the work, even for commercial purposes, all without asking permission.

### Using this font

You may create your own fonts based on this font, and you may incorporate portions of this font into your own font. You may publish your own font under any license, including a commercial license, without any limitations.

