
## GG Star

GG Star is a narrow retro sci-fi display font.

It contains 144 glyphs, and supports 143 characters from the Unicode blocks: Cyrillic, Basic Latin, General Punctuation.

### License

Based on [Daily Double C](https://fontstruct.com/fontstructions/show/1922938) by [Dmitriy Sychiov](https://fontstruct.com/fontstructors/1104892/sychoff) an [Daily Double] (https://fontstruct.com/fontstructions/show/1922853) by [Quinn Davis](https://fontstruct.com/fontstructors/1507185/sonicfontshd).

Dedicated to the public domain via the [CC0 1.0 Universal Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/). No rights reserved.

The person who associated a work with this deed has dedicated the work to the public domain by waiving all of his or her rights to the work worldwide under copyright law, including all related and neighboring rights, to the extent allowed by law. You can copy, modify, distribute and perform the work, even for commercial purposes, all without asking permission.

### Using this font

You may create your own fonts based on this font, and you may incorporate portions of this font into your own font. You may publish your own font under any license, including a commercial license, without any limitations.

