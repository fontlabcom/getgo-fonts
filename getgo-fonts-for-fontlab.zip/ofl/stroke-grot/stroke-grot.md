## GG Stroke Grot OFL

GG Stroke Grot OFL is a single-stroke grotesque sanserif design. You can apply Power Brush or a Stroke to it to experiment.

It contains a basic Latin glyph set.


### License

Based on [Work Sans](https://github.com/weiweihuanghuang/Work-Sans) by Wei Huang.

Copyright 2019 The Work Sans Project Authors (https://github.com/weiweihuanghuang/Work-Sans). Licensed under the [SIL Open Font License, Version 1.1](https://scripts.sil.org/OFL).

### Using this font

You may create your own fonts based on this font, and you may incorporate portions of this font into your own font, but you must publish the resulting font under the same license (SIL Open Font License, Version 1.1):

- in _Font Info › Legal › Copyright_, include `Portions Copyright 2019 The Work Sans Project Authors.`
- in _Font Info › Legal › License_, put `Licensed under the SIL Open Font License, Version 1.1.`
- see [the license](https://scripts.sil.org/OFL) for more details
